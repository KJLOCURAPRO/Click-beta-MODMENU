let modGameTest·CRK_Freatures·tester_Vfour·Htmlpd = false

let dFault = 'blue'


const menumod = document.getElementById('Mod.menu')
const cagarC = document.getElementById('Comprobar')
const modDinero = document.getElementById('dineromod')
const modinter = document.getElementById('ModGameTest·CRK-Freatures')
const dinerotxt = document.getElementById("dinero")
const boton = document.getElementById ("click")
const cs = document.getElementById("clicksound")
const cienw = document.getElementById("100dwin")
const textocien = document.getElementById ("logrocien")
const textodoscientos = document.getElementById ("logrodocientos")
const colorrandom = document.getElementById("random")
const logromiltxt = document.getElementById("logromil")
//ups
const upuno = document.getElementById ("upUno")
//sonidos expanded
const lunoexpanded = document.getElementById("logroexpanded")
const logro_Victory = document.getElementById("logro_grand")
const buy = document.getElementById("buy")
const no = document.getElementById("no")

//boton de menu
const botonmenu = document.getElementById("menub")
const menu = document.getElementById("menu")
const exit = document.getElementById("menuexit")

//misiones
const vericienmenu = document.getElementById('vericienmenu')
const veridosmenu = document.getElementById ("veridosmenu")
const vericincomenu = document.getElementById("vericincomenu")
const verimilmenu = document.getElementById("verimilmenu")
let $ = '$'
let dinero = 0
let añadir = 1
let premioUno = 1
let upno = 1
let vericien = false
veridos = false
let verimil = false
vericinco = false
let dineroActu = setInterval(() =>{
    dinerotxt.innerText = dinero + $;
},0)


boton.addEventListener("click", () => {
    dinero = dinero + añadir;
    dinerotxt.innerText = dinero + $;
    cs.play();
    setTimeout(() => {
        cs.load()
    },500)
    //cienw.play();
    if(dinero >= 100 && vericien == false && dinero<= 199 && modGameTest·CRK_Freatures·tester_Vfour·Htmlpd == false){
        vericienmenu.style.color = 'lime'
    cienw.play();
    textocien.style.display = 'block'
    setTimeout( () => {textocien.style.display = 'none'},7000);
    vericien = 'Completada'
}else if(dinero >= 200 && veridos == false && dinero <= 299 && modGameTest·CRK_Freatures·tester_Vfour·Htmlpd == false){
    veridosmenu.style.color = 'lime'
    lunoexpanded.play();
    añadir = añadir + premioUno
    textodoscientos.style.display = 'block'
    setTimeout( () => {textodoscientos.style.display = 'none'},7000);
    veridos = 'Completada'
}
    if(dinero >= 500 && vericinco == false && dinero <= 599 && modGameTest·CRK_Freatures·tester_Vfour·Htmlpd == false){
        lunoexpanded.volume = 1;
        lunoexpanded.play();
                vericinco = 'Completada'
    }
    if(dinero >= 1000 && verimil == false && dinero <= 1999 && modGameTest·CRK_Freatures·tester_Vfour·Htmlpd == false){
    logro_Victory.play();
    logromiltxt.style.display = 'block'
    verimil = 'Completada'
    setTimeout(() =>{
        logromiltxt.style.display = 'none'
    },7000)
    }
})

//upuno click
upuno.addEventListener("click", () => {

    
    if(dinero >= 500){
        añadir = añadir + upno
        upuno.classList.remove("mal")
        upuno.classList.add("bien")
        setTimeout(() => {
            upuno.classList.remove("bien")
            dinerotxt.classList.remove("mal")

        },500)
        dinero = dinero - 500
        dinerotxt.textContent = dinero + $;
        buy.play();
    }else{
        upuno.classList.remove("bien")
        upuno.classList.add("mal")
        dinerotxt.classList.add("mal")
        setTimeout(() => {
            upuno.classList.remove("mal")
            dinerotxt.classList.remove("mal")

        },500)
        no.play();
    }
})


//menu misiones
botonmenu.addEventListener("click", () => {
    cs.play();
    menu.style.display = 'block';
    dinerotxt.style.display = 'none'
    boton.style.display = 'none'
    upuno.style.display = 'none'
    colorrandom.style.display = 'none'
    menuexit.style.display= 'block'
    menumod.style.display = 'none'
    if(vericien == 'Completada'){
        vericienmenu.textContent = 'Completada'
    }else if(vericien == false && dinero>= 1 && dinero <= 99){
        vericienmenu.style.color = 'yellow'
        vericienmenu.textContent = 'En proceso: ' + dinero + '%'
    }
        else{
        vericienmenu.style.color = 'red'
        vericienmenu.textContent = 'Incompleta'
    }   
        if(veridos == 'Completada'){
        veridosmenu.textContent = 'Completada Ganancia: Bonus +1'
        }else if( veridos == false && vericien == 'Completada'){
            let faltados = dinero - 100
            veridosmenu.style.color = 'yellow'
        veridosmenu.textContent = 'En proceso: ' + faltados + '%'
        }
        else{
        veridosmenu.style.color = 'red'
        veridosmenu.textContent = 'Primero llega a 100'
    }if(vericinco == 'Completada'){
        vericincomenu.textContent = 'Completada'
}if(verimil == 'Completada'){
    verimilmenu.textContent = 'Completada'
    verimilmenu.style.color = 'lime'
}if(dinero > 100 && vericien == false){
    vericienmenu.textContent = 'Uso de trampa'
    vericienmenu.style.color = 'orange'
    
}if(dinero > 200 && veridos == false){
    veridosmenu.textContent = 'Uso de trampa'
    veridosmenu.style.color = 'orange'
 
}if(dinero > 500 && vericinco == false){
    vericincomenu.textContent = 'Uso de trampa'
    vericincomenu.style.color = 'orange'
}
})



exit.addEventListener("click", () => {
    cs.play();
    menumod.style.display = 'block'
    menu.style.display ='none'
    dinerotxt.style.display = 'block'
    boton.style.display = 'inline-block'
    upuno.style.display = 'block'
    menuexit.style.display = 'none'
    colorrandom.style.display = 'block'

})

colorrandom.addEventListener("click", () => {
    if (dinero >= 1000) {
        colorrandom.classList.remove("mal")
        colorrandom.classList.add("bien")
        setTimeout(() => {
            colorrandom.classList.remove("bien")
        },500)
        buy.play();
        
        
        //Color random
        
        r = Math.floor(Math.random() * (256)),
      g = Math.floor(Math.random() * (256)),
      b = Math.floor(Math.random() * (256)),
      color = '#' + r.toString(16) + g.toString(16) + b.toString(16)
    boton.style.backgroundColor = color;
    dinero = dinero - 1000
    dinerotxt.textContent = dinero + $
    }else{
        colorrandom.classList.remove("bien")
        dinerotxt.classList.add("mal")
        colorrandom.classList.add("mal")
        setTimeout(() => {
            colorrandom.classList.remove("mal")
            dinerotxt.classList.remove("mal")

        },500)
        no.play();
    }
})

let modclick = 0

menumod.addEventListener("click", () => {
    
    modinter.style.display = 'block'
    menu.style.display ='none'
    dinerotxt.style.display = 'none'
    boton.style.display = 'none'
    upuno.style.display = 'none'
    menuexit.style.display = 'none'
    colorrandom.style.display = 'none'
    botonmenu.style.display = 'none'
    cagarC.style.display = 'block'
    modclick = modclick + 1
    if(modclick >= 2){
    modinter.style.display = 'none'
    menu.style.display ='none'
    dinerotxt.style.display = 'block'
    boton.style.display = 'inline-block'
    upuno.style.display = 'block'
    menuexit.style.display = 'none'
    colorrandom.style.display = 'block'
    botonmenu.style.display = 'block'
    cagarC.style.display = 'none'
    modclick = 0
    } 

})












