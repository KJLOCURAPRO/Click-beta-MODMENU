//CRK MOD
const modDinero_js = document.getElementById('dineromod')
let modGameTest·CRK_Freatures·tester_Vfour·Htmlpd_js = false
//mod
const cargarC = document.getElementById('Comprobar')
const INPUTCOLOR = document.getElementById ("textocolor")
const fondo = document.getElementById('modfondo')
let rojo = 'red'
azul = 'blue'
negro = 'black'
verde = 'green'
amarillo = 'yellow'
coral = 'coral'


let INPUTCOLORA = []

cargarC.addEventListener("click", () => {
    //console.log(colortxt)
        fondo.style.backgroundColor = INPUTCOLOR.value
        INPUTCOLORA.push(INPUTCOLOR.value)
        
  let fmod = modDinero_js.value
  dinero = parseInt(fmod)
  
    if(modDinero.value != '' && modDinero.value!=0){
modGameTest·CRK_Freatures·tester_Vfour·Htmlpd = true
if(modGameTest·CRK_Freatures·tester_Vfour·Htmlpd == true){
  setInterval( () => {
  vericienmenu.textContent = 'Uso de Gamemod Freatures'
    vericienmenu.style.color = 'blue'
      veridosmenu.textContent = 'Uso de Gamemod Freatures'
    veridosmenu.style.color = 'blue'
      vericincomenu.textContent = 'Uso de Gamemod Freatures'
    vericincomenu.style.color = 'blue'
      verimilmenu.textContent = 'Uso de Gamemod Freatures'
    verimilmenu.style.color = 'blue'
  },1000)
  dinerotxt.style.color = 'blue'
}
}
        
modGameTest·CRK_Freatures·tester_Vfour·Htmlpd_js = true
const root = document.documentElement;
let color = INPUTCOLOR.value
root.style.setProperty('--color-fondo',color)
if (modGameTest·CRK_Freatures·tester_Vfour·Htmlpd_js == true) {
    vericienmenu.style.color = 'darkblue'
    vericienmenu.textContent = 'Uso de GameMod Freatures'
}

})
//valor dinero CRK MODER









